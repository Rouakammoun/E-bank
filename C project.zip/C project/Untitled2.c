#include <stdio.h>
#include <windows.h>

// D�finition des couleurs de la console
enum ConsoleColor {
    Black = 0,
    Blue = 1,
    Green = 2,
    Cyan = 3,
    Red = 4,
    Magenta = 5,
    Yellow = 6,
    White = 7
};

// Fonction pour d�finir la couleur du texte dans la console
void setConsoleColor(enum ConsoleColor text, enum ConsoleColor background) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), text | (background << 4));
}

int main() {
    // Exemple d'utilisation des couleurs
    setConsoleColor(Green, Black);
    printf("Texte en vert sur fond noir\n");

    setConsoleColor(Yellow, Blue);
    printf("Texte en jaune sur fond bleu\n");

    // R�tablir la couleur par d�faut
    setConsoleColor(White, Black);

    return 0;
}


