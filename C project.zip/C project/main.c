#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <time.h>
#define PASSWORD_LENGTH 8
#define DATE_LENGTH 11
typedef struct {
    int year;
    int month;
    int day;
} Date;
enum ConsoleColor {
    Black = 0,
    Blue = 1,
    Green = 2,
    Cyan = 3,
    Red = 4,
    Magenta = 5,
    Yellow = 6,
    White = 7
};
void setConsoleColor(enum ConsoleColor text, enum ConsoleColor background) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), text | (background << 4));
}
typedef struct {
    int transactionNumber;
    char op[10];
    float amount;
} Transaction;
typedef struct Noeud Noeud;
struct Noeud
{
Transaction val;
struct Noeud *suivant;
};
typedef Noeud* Liste;
typedef struct {
    int accountNumber;
    char firstName[20];
    char lastName[20];
    float balance;
    char accountType[20];
    Liste transactions;
    int nbt;
    char password[PASSWORD_LENGTH+1];
    Date creationDate;
} Customer;
Date getCurrentDate() {
    Date currentDate;
    time_t t = time(NULL);
    struct tm* tm_info = localtime(&t);
    currentDate.year = tm_info->tm_year + 1900;
    currentDate.month = tm_info->tm_mon + 1;
    currentDate.day = tm_info->tm_mday;
    return currentDate;
}
Liste ajout_tete(Transaction e, Liste L) {
    Liste p;
    p = malloc(sizeof(Noeud));
    if (p == NULL) {
        fprintf(stderr, "Error allocating memory\n");
        exit(EXIT_FAILURE);
    }
    p->suivant = L;
    p->val = e;
    L = p;
    return L;
}


void formatDateAsString(const Date* date, char* dateString) {
    snprintf(dateString, DATE_LENGTH, "%02d-%02d-%04d", date->day, date->month, date->year);
}
void addRecord(FILE* database, Customer newCustomer) {
    newCustomer.creationDate = getCurrentDate();
    char dateString[DATE_LENGTH];
    formatDateAsString(&newCustomer.creationDate, dateString);
    fprintf(database, "%d %s %s %.2f %s %s \n", newCustomer.accountNumber, newCustomer.firstName, newCustomer.lastName, newCustomer.balance,newCustomer.password,dateString);
}
void createAccount(FILE* database) {
    Customer newCustomer;
    setConsoleColor(3, Black);

    int maxAccountNumber = 0;
    fseek(database, 0, SEEK_SET);

    while (fscanf(database,"%d %*s %*s %*f %*s %*s", &maxAccountNumber) == 1) {
    }

    newCustomer.accountNumber = maxAccountNumber + 1;

    printf("   Entrez le prenom du client : ");
    scanf("%s", newCustomer.firstName);

    printf("   Entrez le nom de famille du client : ");
    scanf("%s", newCustomer.lastName);

    printf("   Entrer la somme a deposer : ");
    scanf("%f", &newCustomer.balance);

    newCustomer.nbt = 0;
    newCustomer.transactions = NULL;
    do {
        printf("  Entrer le mot de passe (8 caract�res) : ");
        scanf("%8s", newCustomer.password);
    } while (strlen(newCustomer.password) != PASSWORD_LENGTH);
    newCustomer.password[PASSWORD_LENGTH] = '\0';

    fseek(database, 0, SEEK_END);

    database = fopen("E-bank.txt", "a");
    if (database == NULL) {
        fprintf(stderr, "! Erreur lors de l'ouverture du fichier.\n");
        exit(EXIT_FAILURE);
    }
    addRecord(database, newCustomer);
    fclose(database);
    setConsoleColor(2, 0);
    printf("  \n       Compte cree avec succes.\n");
}
void updateAccount(FILE* database) {
    int accountNumber;
    printf("   Entrer votre numero de compte: ");
    scanf("%d", &accountNumber);

    fseek(database, 0, SEEK_SET);
    Customer currentCustomer;
    int found = 0;

    FILE* tempFile = fopen("temp.txt", "w");
    if (tempFile == NULL) {
        fprintf(stderr, "Erreur.\n");
        fclose(database);
        exit(EXIT_FAILURE);
    }

    while (fscanf(database, "%d %s %s %f %s %d%d%d",
                  &currentCustomer.accountNumber,
                  currentCustomer.firstName,
                  currentCustomer.lastName,
                  &currentCustomer.balance,
                  currentCustomer.password,
                  &currentCustomer.creationDate.day,
                  &currentCustomer.creationDate.month,
                  &currentCustomer.creationDate.year) == 8) {
        if (currentCustomer.accountNumber == accountNumber) {
            found = 1;
            setConsoleColor(3, Black);
            printf("\n**** Current Account Information ****\n");
            printf("  Account Number: %d\n", currentCustomer.accountNumber);
            printf("  First Name: %s\n", currentCustomer.firstName);
            printf("  Last Name: %s\n", currentCustomer.lastName);
            printf("  Balance: %.2f\n", currentCustomer.balance);
            printf("  Creation Date: %d%d%d\n", currentCustomer.creationDate.day,
                   currentCustomer.creationDate.month, currentCustomer.creationDate.year);

            printf("\n   ****  Update Account Information  ****\n");
            printf("  New First Name: ");
            scanf("%s", currentCustomer.firstName);
            printf("  New Last Name: ");
            scanf("%s", currentCustomer.lastName);
        }

        fprintf(tempFile, "%d %s %s %.2f %s %d%d%d\n",
                currentCustomer.accountNumber,
                currentCustomer.firstName,
                currentCustomer.lastName,
                currentCustomer.balance,
                currentCustomer.password,
                currentCustomer.creationDate.day,
                currentCustomer.creationDate.month,
                currentCustomer.creationDate.year);
    }

    fclose(database);
    fclose(tempFile);

    remove("E-bank.txt");
    rename("temp.txt", "E-bank.txt");
    database = fopen("E-bank.txt", "r");
    if (found) {
        setConsoleColor(2, Black);
        printf("\n         Compte mis a jour avec succes.\n");
    } else {
        setConsoleColor(Red, Black);
        printf("Account not found.\n");

    }
}
void displayAccountDetails(FILE* database) {
    int accountNumber;
    setConsoleColor(3, Black);
    printf("   Entrez le num�ro de compte a afficher : ");
    scanf("%d", &accountNumber);
    fseek(database, 0, SEEK_SET);
    Customer currentCustomer;
    int found = 0;
    int result;
    while ((result = fscanf(database, "%d %s %s %f %s %d %d %d",
                           &currentCustomer.accountNumber,
                           currentCustomer.firstName,
                           currentCustomer.lastName,
                           &currentCustomer.balance,
                           currentCustomer.password,
                           &currentCustomer.creationDate.day,
                           &currentCustomer.creationDate.month,
                           &currentCustomer.creationDate.year)) == 8) {
        if (currentCustomer.accountNumber == accountNumber) {
            found = 1;
            setConsoleColor(3, Black);
            printf("\n    ====  Details du compte  ====\n");
            setConsoleColor(2, Black);
            printf("\n   Numero de compte : %d\n", currentCustomer.accountNumber);
            printf("\n   Prenom : %s\n", currentCustomer.firstName);
            printf("\n   Nom de famille : %s\n", currentCustomer.lastName);
            printf("\n   Solde : %.2f\n", currentCustomer.balance);
            break;
        }
    }

    if (!found) {
        setConsoleColor(Red, Black);
        printf("Compte non trouve.\n");
    }
}
void displayCustomerList(FILE* database) {
    fseek(database, 0, SEEK_SET);
    Customer currentCustomer;
    setConsoleColor(3, Black);
    printf("\n      ====   Liste des clients   ====\n");

    int result;
    while ((result = fscanf(database, "%d %s %s %f %s %d %d %d",
                           &currentCustomer.accountNumber,
                           currentCustomer.firstName,
                           currentCustomer.lastName,
                           &currentCustomer.balance,
                           currentCustomer.password,
                           &currentCustomer.creationDate.day,
                           &currentCustomer.creationDate.month,
                           &currentCustomer.creationDate.year)) == 8) {
        printf("Numero de compte : %d, Prenom : %s, Nom de famille : %s, Solde : %.2f\n",
               currentCustomer.accountNumber,
               currentCustomer.firstName,
               currentCustomer.lastName,
               currentCustomer.balance);
    }



}
void deleteAccount(FILE* database) {
    int accountNumber;
    printf("Entrez le numero de compte a supprimer : ");
    scanf("%d", &accountNumber);
    fseek(database, 0, SEEK_SET);
    Customer currentCustomer;
    long currentPosition = ftell(database);
    int found = 0;

    int result;
    while ((result = fscanf(database, "%d %s %s %f %s %d %d %d",
                           &currentCustomer.accountNumber,
                           currentCustomer.firstName,
                           currentCustomer.lastName,
                           &currentCustomer.balance,
                           currentCustomer.password,
                           &currentCustomer.creationDate.day,
                           &currentCustomer.creationDate.month,
                           &currentCustomer.creationDate.year)) == 8) {
        if (currentCustomer.accountNumber == accountNumber) {
            found = 1;
            break;
        }
        currentPosition = ftell(database);
    }

    if (found) {
        printf("\n   =====  Informations du compte a supprimer  =====\n");
        printf("Numero de compte : %d\n", currentCustomer.accountNumber);
        printf("Prenom : %s\n", currentCustomer.firstName);
        printf("Nom de famille : %s\n", currentCustomer.lastName);
        printf("Solde : %.2f\n", currentCustomer.balance);

        char confirmation[4];
        printf("Voulez-vous vraiment supprimer ce compte ? (OUI/NON) : ");
        scanf("%3s", confirmation);

        if (strcmp(confirmation, "OUI") == 0 || strcmp(confirmation, "oui") == 0 || strcmp(confirmation, "Oui") == 0) {
            FILE* tempFile = fopen("temp.txt", "w");

            if (tempFile == NULL) {
                fprintf(stderr, "Erreur .\n");
                fclose(database);
                exit(EXIT_FAILURE);
            }

            fseek(database, 0, SEEK_SET);
            while ((result = fscanf(database, "%d %s %s %f %s %d%d%d",
                           &currentCustomer.accountNumber,
                           currentCustomer.firstName,
                           currentCustomer.lastName,
                           &currentCustomer.balance,
                           currentCustomer.password,
                           &currentCustomer.creationDate.day,
                           &currentCustomer.creationDate.month,
                           &currentCustomer.creationDate.year)) == 8) {
                if (currentCustomer.accountNumber != accountNumber) {
                    fprintf(tempFile, "%d %s %s %.2f %s %d%d%d \n", currentCustomer.accountNumber, currentCustomer.firstName, currentCustomer.lastName, currentCustomer.balance,currentCustomer.password,currentCustomer.creationDate.day,
                           currentCustomer.creationDate.month,
                           currentCustomer.creationDate.year);
                }
            }
            fclose(database);
            fclose(tempFile);
            remove("E-bank.txt");
            rename("temp.txt", "E-bank.txt");
            printf("Compte supprime avec succes.\n");
            database = fopen("E-bank.txt", "r");
        } else {
            printf("Suppression annulee.\n");
        }
    } else {
        printf("Compte non trouve.\n");
    }
}
void displayTransaction(Transaction* transaction) {
    printf("Numero de transaction : %d\n", transaction->transactionNumber);
    printf("Operation : %s\n", transaction->op);
    printf("Montant : %.2f\n", transaction->amount);
}

void view_transaction(FILE* database) {
    setConsoleColor(3, Black);
    printf("     Entrez le numero de votre compte : ");
    int ac;
    scanf("%d", &ac);

    fseek(database, 0, SEEK_SET);
    Customer currentCustomer;
    long currentPosition = ftell(database);
    int found = 0;

    int result;
    while ((result = fscanf(database, "%d %s %s %f %s %d %d %d",
                           &currentCustomer.accountNumber,
                           currentCustomer.firstName,
                           currentCustomer.lastName,
                           &currentCustomer.balance,
                           currentCustomer.password,
                           &currentCustomer.creationDate.day,
                           &currentCustomer.creationDate.month,
                           &currentCustomer.creationDate.year)) == 8) {
        if (currentCustomer.accountNumber == ac) {
            found = 1;
            break;
        }
        currentPosition = ftell(database);
    }

    if (found) {
        if (currentCustomer.transactions == NULL) {
            setConsoleColor(4, Black);
            printf(  "\n     Aucune transaction n'a ete effectuee pour ce compte.\n");
        } else {
            setConsoleColor(3, Black);
            printf("==== Transactions du compte ====\n");
            Liste aux = currentCustomer.transactions;
            while (aux != NULL) {
                displayTransaction(&(aux->val));
                aux = aux->suivant;
            }
        }
    } else {
        setConsoleColor(4, Black);
        printf("Compte non trouve.\n");
    }
}
void gerertransaction(FILE* database) {
    setConsoleColor(3, Black);
    printf("  Entrez le numero de votre compte : ");
    int ac;
    scanf("%d", &ac);

    fseek(database, 0, SEEK_SET);
    Customer currentCustomer;
    long currentPosition = ftell(database);
    int found = 0;

    int result;
    while ((result = fscanf(database, "%d %s %s %f %s %d %d %d",
                           &currentCustomer.accountNumber,
                           currentCustomer.firstName,
                           currentCustomer.lastName,
                           &currentCustomer.balance,
                           currentCustomer.password,
                           &currentCustomer.creationDate.day,
                           &currentCustomer.creationDate.month,
                           &currentCustomer.creationDate.year)) == 8) {
        if (currentCustomer.accountNumber == ac) {
            found = 1;
            break;
        }
        currentPosition = ftell(database);
    }

    if (found) {

        printf("          ====   Vous pouvez choisir le service d�sir�   ====\n");
        printf("   1. Deposer de l'argent\n");
        printf("   2. Retirer de l'argent\n");
        int choix;
        scanf("%d", &choix);

        if (choix == 1) {
            setConsoleColor(3, Black);
            printf("   Taper le montant a deposer : ");
            float a;
            scanf("%f", &a);

            Transaction T;
            T.transactionNumber = currentCustomer.nbt + 128;
            T.amount = a;
            currentCustomer.nbt++;
            strcpy(T.op, "depot");
            currentCustomer.transactions = ajout_tete(T, currentCustomer.transactions);

            FILE* tempFile = fopen("temp.txt", "w");
            if (tempFile == NULL) {
                fprintf(stderr, "Erreur.\n");
                exit(EXIT_FAILURE);
            }
            fseek(database, 0, SEEK_SET);
            while ((fscanf(database, "%d %s %s %f %s %d %d %d",
               &currentCustomer.accountNumber,
               currentCustomer.firstName,
               currentCustomer.lastName,
               &currentCustomer.balance,
               currentCustomer.password,
               &currentCustomer.creationDate.day,
               &currentCustomer.creationDate.month,
               &currentCustomer.creationDate.year)) == 8) {
    if (currentCustomer.accountNumber == ac) {
        currentCustomer.balance += a;
    }
    fprintf(tempFile, "%d %s %s %.2f %s %d%d%d\n",
            currentCustomer.accountNumber,
            currentCustomer.firstName,
            currentCustomer.lastName,
            currentCustomer.balance,
            currentCustomer.password,
            currentCustomer.creationDate.day,
            currentCustomer.creationDate.month,
            currentCustomer.creationDate.year);
}


            fclose(database);
            fclose(tempFile);

            remove("E-bank.txt");
            rename("temp.txt", "E-bank.txt");
            database = fopen("E-bank.txt", "r");


            setConsoleColor(2, Black);
            printf("\n        Transaction terminee avec succes\n");
        } else if (choix == 2) {
            setConsoleColor(3, Black);
            printf("   Taper le montant a retirer : ");
            float a;
            scanf("%f", &a);

            if (a > currentCustomer.balance) {
                setConsoleColor(Red, Black);
                printf("\n   OUPS! Solde insuffisant \n");
            } else {

                Transaction T;
                T.transactionNumber = currentCustomer.nbt + 234;
                strcpy(T.op, "retrait");
                currentCustomer.nbt++;
                T.amount = a;
                currentCustomer.transactions = ajout_tete(T, currentCustomer.transactions);

                FILE* tempFile = fopen("temp.txt", "w");
            if (tempFile == NULL) {
                setConsoleColor(Red, Black);
                fprintf(stderr, "Erreur.\n");
                exit(EXIT_FAILURE);
            }
            fseek(database, 0, SEEK_SET);
            while ((fscanf(database, "%d %s %s %f %s %d %d %d",
               &currentCustomer.accountNumber,
               currentCustomer.firstName,
               currentCustomer.lastName,
               &currentCustomer.balance,
               currentCustomer.password,
               &currentCustomer.creationDate.day,
               &currentCustomer.creationDate.month,
               &currentCustomer.creationDate.year)) == 8) {
    if (currentCustomer.accountNumber == ac) {
        currentCustomer.balance -= a;
    }
    fprintf(tempFile, "%d %s %s %.2f %s %d%d%d\n",
            currentCustomer.accountNumber,
            currentCustomer.firstName,
            currentCustomer.lastName,
            currentCustomer.balance,
            currentCustomer.password,
            currentCustomer.creationDate.day,
            currentCustomer.creationDate.month,
            currentCustomer.creationDate.year);
}
           fclose(database);
           fclose(tempFile);
           remove("E-bank.txt");
           rename("temp.txt", "E-bank.txt");
           database = fopen("E-bank.txt", "r");
            setConsoleColor(2, Black);
            printf("\n        Transaction terminee avec succes\n");
        }} else {
            setConsoleColor(Red, Black);
            printf("Choix invalide.\n");
        }
    } else {
        printf("Compte non trouv�.\n");
    }
}

void changePassword(FILE* database) {
    int accountNumber;
    char oldPassword[9];
    char newPassword[9];
    setConsoleColor(4, Black);
    printf("   Entrer le numero du compte : ");
    scanf("%d", &accountNumber);

    printf("   Entrer l'ancien mot de passe : ");
    scanf("%s", oldPassword);

    printf("   Entrer le nouveau mot de passe : ");
    scanf("%s", newPassword);

    fseek(database, 0, SEEK_SET);
    Customer currentCustomer;
    int found = 0;

    FILE* tempFile = fopen("temp.txt", "w");
    if (tempFile == NULL) {
        fprintf(stderr, "Erreur.\n");
        fclose(database);
        exit(EXIT_FAILURE);
    }

    while (fscanf(database, "%d %s %s %f %s %d%d%d",
                  &currentCustomer.accountNumber,
                  currentCustomer.firstName,
                  currentCustomer.lastName,
                  &currentCustomer.balance,
                  currentCustomer.password,
                  &currentCustomer.creationDate.day,
                  &currentCustomer.creationDate.month,
                  &currentCustomer.creationDate.year) == 8) {
        if (currentCustomer.accountNumber == accountNumber &&
            strcmp(currentCustomer.password, oldPassword) == 0) {
            found = 1;
            strcpy(currentCustomer.password, newPassword);
        }

        fprintf(tempFile, "%d %s %s %.2f %s %d%d%d\n",
                currentCustomer.accountNumber,
                currentCustomer.firstName,
                currentCustomer.lastName,
                currentCustomer.balance,
                currentCustomer.password,
                currentCustomer.creationDate.day,
                currentCustomer.creationDate.month,
                currentCustomer.creationDate.year);
    }

    fclose(database);
    fclose(tempFile);

    remove("E-bank.txt");
    rename("temp.txt", "E-bank.txt");
    database = fopen("E-bank.txt", "r");
    if (found == 1) {
        setConsoleColor(2, Black);
        printf("\n        Mot de passe mis a jour avec succes.\n");
    } else {
        setConsoleColor(Red, Black);
        printf("\n        Compte non trouvee ou mot de passe incorrecte.\n");
    }
}
void transferMoney(FILE* database) {
    int sourceAccountNumber, destinationAccountNumber;
    float amount;
    setConsoleColor(4, Black);
    printf("    Entrer le numero de votre compte: ");
    scanf("%d", &sourceAccountNumber);
    printf("    Entrer le numero du compte pourlequelle vous souhaitez transferer la somme : ");
    scanf("%d", &destinationAccountNumber);
    printf("    Entrer la somme a transferer: ");
    scanf("%f", &amount);
    fseek(database, 0, SEEK_SET);
    Customer sourceCustomer;
    int sourceFound = 0;
    int result;
    while ((result = fscanf(database, "%d %s %s %f %s %d %d %d",
                           &sourceCustomer.accountNumber,
                           sourceCustomer.firstName,
                           sourceCustomer.lastName,
                           &sourceCustomer.balance,
                           sourceCustomer.password,
                           &sourceCustomer.creationDate.day,
                           &sourceCustomer.creationDate.month,
                           &sourceCustomer.creationDate.year)) == 8) {
        if (sourceCustomer.accountNumber == sourceAccountNumber) {
            sourceFound = 1;
            break;
        }
    }
    if (!sourceFound) {
        setConsoleColor(Red, Black);
        printf("ERREUR: Compte source non trouve.\n");
        return;
    }
    if (sourceCustomer.balance < amount) {
        setConsoleColor(Red, Black);
        printf("ERREUR: Solde insuffisant.\n");
        return;
    }
    fseek(database, 0, SEEK_SET);
    Customer destinationCustomer;
    int destinationFound = 0;


    while ((result = fscanf(database, "%d %s %s %f %s %d %d %d",
                           &destinationCustomer.accountNumber,
                           destinationCustomer.firstName,
                           destinationCustomer.lastName,
                           &destinationCustomer.balance,
                           destinationCustomer.password,
                           &destinationCustomer.creationDate.day,
                           &destinationCustomer.creationDate.month,
                           &destinationCustomer.creationDate.year)) == 8) {
        if (destinationCustomer.accountNumber == destinationAccountNumber) {
            destinationFound = 1;
            break;
        }
    }

    if (!destinationFound) {
        setConsoleColor(Red, Black);
        printf("ERREUR: Compte non trouve.\n");
        return;
    }
    sourceCustomer.balance -= amount;
    destinationCustomer.balance += amount;
    Transaction sourceTransaction, destinationTransaction;
    sourceTransaction.transactionNumber = sourceCustomer.nbt + 345;
    destinationTransaction.transactionNumber = destinationCustomer.nbt + 456;
    sourceTransaction.amount = -amount;
    destinationTransaction.amount = amount;
    strcpy(sourceTransaction.op, "transfert-sortant");
    strcpy(destinationTransaction.op, "transfert-entrant");
    sourceCustomer.nbt++;
    destinationCustomer.nbt++;
    sourceCustomer.transactions = ajout_tete(sourceTransaction, sourceCustomer.transactions);
    destinationCustomer.transactions = ajout_tete(destinationTransaction, destinationCustomer.transactions);
    FILE* tempFile = fopen("temp.txt", "w");
    if (tempFile == NULL) {
        fprintf(stderr, "Erreur.\n");
        exit(EXIT_FAILURE);
    }
    Customer currentCustomer;
    fseek(database, 0, SEEK_SET);
    while ((fscanf(database, "%d %s %s %f %s %d %d %d",
                   &currentCustomer.accountNumber,
                   currentCustomer.firstName,
                   currentCustomer.lastName,
                   &currentCustomer.balance,
                   currentCustomer.password,
                   &currentCustomer.creationDate.day,
                   &currentCustomer.creationDate.month,
                   &currentCustomer.creationDate.year)) == 8) {
        if (currentCustomer.accountNumber == sourceAccountNumber) {
            currentCustomer.balance = sourceCustomer.balance;
            fprintf(tempFile, "%d %s %s %.2f %s %d%d%d\n",
                    currentCustomer.accountNumber,
                    currentCustomer.firstName,
                    currentCustomer.lastName,
                    currentCustomer.balance,
                    currentCustomer.password,
                    currentCustomer.creationDate.day,
                    currentCustomer.creationDate.month,
                    currentCustomer.creationDate.year);
        } else if (currentCustomer.accountNumber == destinationAccountNumber) {
            currentCustomer.balance = destinationCustomer.balance;
            fprintf(tempFile, "%d %s %s %.2f %s %d%d%d\n",
                    currentCustomer.accountNumber,
                    currentCustomer.firstName,
                    currentCustomer.lastName,
                    currentCustomer.balance,
                    currentCustomer.password,
                    currentCustomer.creationDate.day,
                    currentCustomer.creationDate.month,
                    currentCustomer.creationDate.year);
        } else {
            fprintf(tempFile, "%d %s %s %.2f %s %d%d%d\n",
                    currentCustomer.accountNumber,
                    currentCustomer.firstName,
                    currentCustomer.lastName,
                    currentCustomer.balance,
                    currentCustomer.password,
                    currentCustomer.creationDate.day,
                    currentCustomer.creationDate.month,
                    currentCustomer.creationDate.year);
        }
    }

    fclose(database);
    fclose(tempFile);
    remove("E-bank.txt");
    rename("temp.txt", "E-bank.txt");
    database = fopen("E-bank.txt", "r");
    setConsoleColor(2, Black);
    printf("\n        Argent transfere avec succes du compte %d vers compte %d.\n", sourceAccountNumber, destinationAccountNumber);
}
int main(){
    FILE* database;
    database = fopen("E-bank.txt", "a+");
    if (database == NULL) {
        setConsoleColor(Red, Black);
        fprintf(stderr, "Impossible d'ouvrir la base de donnees.\n");
        exit(EXIT_FAILURE);
    }
    int choice;
    do {
        setConsoleColor(5,Black);
        printf("\n       ~~~ TAPER LE NUMERO DU SERVICE SOUHAITE ~~~\n");
        setConsoleColor(Blue,Black);
        printf("            1. creer un nouveau compte\n");
        printf("            2. mettre a jour un compte\n");
        printf("            3. Display account details\n");
        printf("            4. Afficher les transactions bancaires\n");
        printf("            5. gerer les transactions bancaires\n");
        printf("            6. afficher la liste des clients\n");
        printf("            7. Supprimer un compte \n");
        printf("            8. Transferer de l'argent \n");
        printf("            9. changer le mot de passe \n");
        printf("            0. Quitter\n");
        setConsoleColor(White,Black);
        printf("Choix : ");
        scanf("%d", &choice);
        int numCustomers=0;
        switch (choice) {
            case 1:
                createAccount( database);

                break;
            case 2:
                updateAccount(database);
                break;
            case 3:
                displayAccountDetails(database);
                break;
            case 4:
                view_transaction(database );
                break;
            case 5:
                gerertransaction( database);
                break;
            case 6:
                displayCustomerList(database);
                break;
            case 7:
                deleteAccount( database);
                break;
            case 8:
                transferMoney(database);
                break;
            case 9:
                changePassword(database);
                break;
            case 0:
                setConsoleColor(Red, Black);
                printf("     Au revoir!\n");
                break;
            default:
                printf("Choix invalide. Veuillez reessayer.\n");
                break;
        }
    } while (choice != 0);
    fclose(database);
    return 0;
}
